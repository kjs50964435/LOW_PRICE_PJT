16 June 2019

                                                Apache Lounge Distribution

                                          dbd-modules 1.0.6 Apache 2.4 Win64 VS16

# Original source by: Tom Donovan
# Original Home: http://sourceforge.net/projects/dbd-modules/
# Binary by: Steffen
# Mail: info@apachelounge.com
# Home: http://www.apachelounge.com/

Build with Visual Studio� 2019 (VS16) 
--------------------------------------------
Be sure you have installed the Visual C++ Redistributable for Visual Studio 2015-2019.
Download and install, if you not have it already, see:

 http://www.apachelounge.com/download/


DBD MODULES - Two Apache modules to allow Apache 2.4 to access databases using DBD.

    mod_log_dbd     - Log web requests to an SQL database
    mod_vhost_dbd   - Override the document root directory from an SQL database



The configuration instructions are at:

    http://sourceforge.net/p/dbd-modules/wiki/mod_vhost_dbd/

    http://sourceforge.net/p/dbd-modules/wiki/mod_log_dbd/

mod_log_dbd must be loaded after mod_rewrite !

Enjoy,

Steffen